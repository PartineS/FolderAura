# FolderAura v1.0.0 - Kurulum Paketi

## 📦 Paket İçeriği
Bu pakette FolderAura uygulamasını kullanmanız için gereken tüm dosyalar bulunmaktadır:

- **FolderAura.exe** - Ana uygulama (8MB)
- **install.cmd** - Otomatik kurulum scripti
- **uninstall.cmd** - Kaldırma scripti
- **README_TR.md** - Türkçe kullanım kılavuzu
- **README_EN.md** - İngilizce kullanım kılavuzu

## 🚀 Hızlı Kurulum

### Otomatik Kurulum (Önerilen)
1. **install.cmd** dosyasına **sağ tıklayın**
2. **"Yönetici olarak çalıştır"** seçin
3. Kurulum sihirbazını takip edin
4. Başlat menüsünden "FolderAura" arayarak başlatın

### Manuel Kullanım
1. **FolderAura.exe** dosyasına **sağ tıklayın**
2. **"Yönetici olarak çalıştır"** seçin
3. Uygulamayı doğrudan kullanın

## 🗑️ Kaldırma
- **Otomatik kurulum yaptıysanız**: Denetim Masası → Program Ekle/Kaldır → FolderAura
- **Manuel kullanıyorsanız**: **uninstall.cmd** dosyasını yönetici olarak çalıştırın

## 📖 Detaylı Bilgi
- **Türkçe kılavuz**: README_TR.md dosyasını açın
- **İngilizce kılavuz**: README_EN.md dosyasını açın

## ⚠️ Önemli Notlar
- Uygulama **yönetici izni** gerektirir
- Windows 10/11 sistemlerde çalışır
- .NET 8.0 otomatik yüklenecektir

---
**FolderAura v1.0.0** - Masaüstü Klasör Özelleştirme Uygulaması
