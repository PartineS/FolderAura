# FolderAura - Standalone Executable

Bu klasördeki FolderAura.exe dosyası tek başına çalışır.
Kurulum gerektirmez, doğrudan çalıştırabilirsiniz.

## ÖNEMLİ:
- Yönetici izinleri ile çalıştırın (sağ tık > Yönetici olarak çalıştır)
- Windows 10/11 gereklidir
- Antivirus yazılımları tarafından engellenebilir (güvenli olarak işaretleyin)

## KULLANIM:

### Kolay Başlatma:
1. `launch-admin.bat` dosyasını çift tıklayın (Otomatik yönetici izni)
2. VEYA `FolderAura.exe`'yi sağ tıklayıp "Yönetici olarak çalıştır"

### Ana Özellikler:
1. FolderAura.exe'yi çalıştırın
2. "Gözat" butonuna basın ve klasör seçin
3. İkon ve efektleri uygulayın
4. Ayarlarınızı kaydedin

### Görsel Efektler:
- **Yok**: Standart görünüm
- **Mica**: Windows 11 özel efekti (sadece Win11)
- **Acrylic**: Mat cam efekti 
- **Saydamlık**: Bulanıklık efekti

### İkon Değiştirme:
- .ico dosyaları seçebilirsiniz
- Klasöre otomatik desktop.ini oluşturulur
- Explorer'da yeni ikon görünür

### Renk ve Etiket:
- Klasörlere renk kodları atayın
- Açıklama etiketleri ekleyin
- JSON dosyasında otomatik kaydedilir

## SORUN YAŞARSANIZ:
- Windows güncellemelerini kontrol edin
- .NET 8.0 Runtime yüklü olduğunu doğrulayın
- Klasör yazma izinlerinizi kontrol edin
- Antivirus'ün dosyayı engellemediğinden emin olun

## TEKNİK BİLGİ:
- Dosya Boyutu: ~70MB
- Platform: Windows x64
- .NET: 8.0 (dahili)
- Bellek Kullanımı: Optimize edilmiş
- Yönetici İzinleri: Gerekli

## GÜVENLİK:
Bu dosya dijital olarak imzalanmamıştır. Güvenilir kaynaklardan indirdiğinizden emin olun.
Antivirus uyarısı alırsanız "güvenli" olarak işaretleyebilirsiniz.

---
FolderAura v1.0 | © 2025 FolderAura Team
